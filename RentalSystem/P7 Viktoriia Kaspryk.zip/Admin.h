//#pragma once
//#ifndef ADMIN_H
//#define ADMIN_H
//#include <string>
//
//using namespace std;
//
//class Admin
//{
//private:
//	string adminName;
//	string adminSurname;
//	string adminPassword;
//
//public:
//	Admin();
//
//	Admin(const string& adminName, const string& adminSurname, const string& adminPassword);
//	bool authenticate(const string& adminName, const string& adminSurname, const string& adminPassword);
//};
//
//
//#endif// ADMIN_H

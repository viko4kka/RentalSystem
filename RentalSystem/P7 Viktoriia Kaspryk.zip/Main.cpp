#include <wx/wx.h>
#include "RentalSystemMainFrame.h"


